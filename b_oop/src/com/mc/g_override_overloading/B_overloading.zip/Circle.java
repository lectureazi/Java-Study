package com.mc.g_override_overloading.B_overloading;

//DTO : Data transfer object
//데이터만을 다루기 위해 생성하는 클래스
public class Circle {
	
	private double radius;

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}
}
