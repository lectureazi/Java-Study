package com.mc.g_override_overloading.A_override;

public class Figure {
	
	public double calArea() {
		return 0.0;
	}

}
