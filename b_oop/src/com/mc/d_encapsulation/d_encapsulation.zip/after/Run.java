package com.mc.d_encapsulation.after;

public class Run {

	public static void main(String[] args) {
		
				

	}
}
