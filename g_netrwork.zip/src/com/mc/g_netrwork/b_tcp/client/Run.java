package com.mc.g_netrwork.b_tcp.client;

public class Run {

	public static void main(String[] args) {
		new TCPClient().clientStart();
	}

}
