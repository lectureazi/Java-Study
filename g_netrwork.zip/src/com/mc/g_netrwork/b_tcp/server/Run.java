package com.mc.g_netrwork.b_tcp.server;

public class Run {

	public static void main(String[] args) {
		new TCPServer().serverStart();
	}

}
