package com.mc.g_netrwork.a_inet;

public class Run {

	public static void main(String[] args) {
		
		_Inet inet = new _Inet();
		inet.studyInet();

	}

}
