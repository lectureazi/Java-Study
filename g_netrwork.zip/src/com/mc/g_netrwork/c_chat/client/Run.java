package com.mc.g_netrwork.c_chat.client;

public class Run {

	public static void main(String[] args) {
		
		new ChatClient().startChat();

	}

}
