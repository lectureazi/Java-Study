package com.mc.exception.runtime;

public class Run {

	public static void main(String[] args) {

		_Exception ex = new _Exception();
		ex.studyMultiException();
	}

}
