package com.mc.lang.object;

public class Author {
	
	private String name;
	private int age;
	private char gender;
	
	public Author(String name, int age, char gender) {
		super();
		this.name = name;
		this.age = age;
		this.gender = gender;
	}
}
