package com.mc.lang.string;

public class Run {
	
	public static void main(String[] args) {
		
		//_String str = new _String();
		//str.readAPIDocument();
		
		StringConcatenation sc = new StringConcatenation();
		sc.testConcat();
	}

}
