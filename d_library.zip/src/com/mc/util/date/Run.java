package com.mc.util.date;

public class Run {
	
	public static void main(String[] args) {
		_Date date = new _Date();
		date.studyLocalDateTime();
	}

}
