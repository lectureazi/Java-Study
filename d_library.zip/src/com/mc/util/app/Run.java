package com.mc.util.app;

public class Run {

	public static void main(String[] args) {
		
		new Menu().menu();
	}

}
