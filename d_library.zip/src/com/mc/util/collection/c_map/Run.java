package com.mc.util.collection.c_map;

public class Run {
	
	public static void main(String[] args) {
		new _Map().studyMap();
	}

}
