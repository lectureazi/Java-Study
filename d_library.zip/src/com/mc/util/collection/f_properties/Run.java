package com.mc.util.collection.f_properties;

public class Run {
	
	public static void main(String[] args) {
		
		_Properties props = new _Properties();
		//props.studyProperties();
		props.loadFromXML();
		
		
	}

}
