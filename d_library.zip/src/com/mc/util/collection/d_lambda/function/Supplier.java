package com.mc.util.collection.d_lambda.function;

@FunctionalInterface
public interface Supplier<T> {
	T get();
}
