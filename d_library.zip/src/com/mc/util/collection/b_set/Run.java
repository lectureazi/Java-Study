package com.mc.util.collection.b_set;

public class Run {
	
	public static void main(String[] args) {
		new _Set().studySet();
	}

}
